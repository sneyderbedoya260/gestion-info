from service import (
    new_register,
    list_records,
    search_record,
    filter_records,
    update_record,
    delete_record,
)


def imprimir_repuesto(r: dict) -> None:
    print(f"  [{r['codigo']}] {r['nombre']}")
    print(f"    Categoria : {r['categoria']}")
    print(f"    Marca moto: {r['marca_moto']}")
    print(f"    Precio    : ${r['precio']:,.2f}")
    print(f"    Stock     : {r['stock']} unidades")
    if r["descripcion"]:
        print(f"    Descripcion: {r['descripcion']}")
    print()


def seccion(titulo: str) -> None:
    print()
    print("=" * 50)
    print(titulo)
    print("=" * 50)


def main():

    # CREATE
    seccion("CREATE — Registrar repuestos")

    repuestos = [
        {"codigo": "FLT001", "nombre": "Filtro de aire CB190", "categoria": "filtros", "marca_moto": "honda", "precio": 35000, "stock": 12, "descripcion": "Compatible con modelos CB190R y CB190X"},
        {"codigo": "FRN002", "nombre": "Pastilla de freno delantera", "categoria": "frenos", "marca_moto": "yamaha", "precio": 48500, "stock": 8},
        {"codigo": "MTR003", "nombre": "Kit de arrastre", "categoria": "transmision", "marca_moto": "bajaj", "precio": 120000, "stock": 5, "descripcion": "Cadena + corona + pinon"},
        {"codigo": "ELC004", "nombre": "Regulador de voltaje", "categoria": "electrico", "marca_moto": "honda", "precio": 75000, "stock": 3},
        {"codigo": "SUS005", "nombre": "Amortiguador trasero", "categoria": "suspension", "marca_moto": "yamaha", "precio": 210000, "stock": 2, "descripcion": "Repuesto original de fabrica"},
        {"codigo": "FLT006", "nombre": "Filtro de aceite", "categoria": "filtros", "marca_moto": "honda", "precio": 22000, "stock": 20},
        {"codigo": "FLT001", "nombre": "Filtro duplicado", "categoria": "filtros", "marca_moto": "honda", "precio": 10000, "stock": 1},
        {"codigo": "XX", "nombre": "A", "categoria": "inexistente", "marca_moto": "honda", "precio": -500, "stock": "no es numero"},
    ]

    for datos in repuestos:
        ok, mensaje = new_register(datos)
        print(f"[{'OK' if ok else 'ERROR'}] {mensaje}")

    # READ — listar todos
    seccion("READ — Listar todos (ordenados por precio)")
    for r in list_records(ordenar_por="precio"):
        imprimir_repuesto(r)

    # READ — buscar por codigo
    seccion("READ — Buscar por codigo")
    for codigo in ["FRN002", "ZZZ999", "XX"]:
        ok, resultado = search_record(codigo)
        if ok:
            imprimir_repuesto(resultado)
        else:
            print(f"[ERROR] {resultado}\n")

    # READ — filtrar
    seccion("READ — Filtrar: marca=honda, ordenado por nombre")
    filtrados = filter_records(marca_moto="honda", ordenar_por="nombre")
    if filtrados:
        for r in filtrados:
            imprimir_repuesto(r)
    else:
        print("Sin resultados.\n")

    seccion("READ — Filtrar: categoria=filtros")
    for r in filter_records(categoria="filtros"):
        imprimir_repuesto(r)

    # UPDATE
    seccion("UPDATE — Modificar registros")
    casos_update = [
        ("FRN002", {"precio": 52000, "stock": 15}),
        ("MTR003", {"descripcion": "Incluye kit de instalacion"}),
        ("ZZZ999", {"stock": 5}),
        ("FLT001", {"codigo": "OTRO"}),
        ("ELC004", {"precio": -100}),
    ]
    for codigo, cambios in casos_update:
        ok, mensaje = update_record(codigo, cambios)
        print(f"[{'OK' if ok else 'ERROR'}] {mensaje}")

    # READ — verificar update
    seccion("READ — Estado tras updates (ordenado por codigo)")
    for r in list_records():
        imprimir_repuesto(r)

    # DELETE
    seccion("DELETE — Eliminar registros")
    for codigo in ["SUS005", "ZZZ999", "XY"]:
        ok, mensaje = delete_record(codigo)
        print(f"[{'OK' if ok else 'ERROR'}] {mensaje}")

    # READ — estado final
    seccion("READ — Estado final del inventario")
    registros = list_records()
    print(f"Total: {len(registros)} repuestos\n")
    for r in registros:
        imprimir_repuesto(r)


if __name__ == "__main__":
    main()
