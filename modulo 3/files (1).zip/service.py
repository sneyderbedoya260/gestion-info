from validate import validar_repuesto, validar_codigo
from file import load_data, save_data


def _normalizar(datos: dict) -> dict:
    return {
        "codigo": datos["codigo"].strip().upper(),
        "nombre": datos["nombre"].strip(),
        "categoria": datos["categoria"].strip().lower(),
        "marca_moto": datos["marca_moto"].strip().lower(),
        "precio": round(float(datos["precio"]), 2),
        "stock": int(datos["stock"]),
        "descripcion": datos.get("descripcion", "").strip(),
    }


# CREATE
def new_register(datos: dict) -> tuple[bool, str]:
    ok, errores = validar_repuesto(datos)
    if not ok:
        return False, "\n".join(errores)

    datos = _normalizar(datos)
    codigo = datos["codigo"]

    inventario = load_data()

    if codigo in inventario:
        return False, f"Ya existe un repuesto con el codigo '{codigo}'."

    inventario[codigo] = datos
    if not save_data(inventario):
        return False, f"El repuesto '{codigo}' se proceso pero no se pudo guardar en disco."

    return True, f"Repuesto '{codigo}' registrado correctamente."


# READ — lista todos, con orden opcional por campo
def list_records(ordenar_por: str = "codigo") -> list[dict]:
    inventario = load_data()
    campos_validos = {"codigo", "nombre", "categoria", "marca_moto", "precio", "stock"}

    if ordenar_por not in campos_validos:
        ordenar_por = "codigo"

    return sorted(inventario.values(), key=lambda r: r[ordenar_por])


# READ — busqueda por codigo exacto
def search_record(codigo: str) -> tuple[bool, dict | str]:
    ok, mensaje = validar_codigo(codigo)
    if not ok:
        return False, f"Codigo invalido: {mensaje}"

    inventario = load_data()
    codigo = codigo.strip().upper()

    if codigo not in inventario:
        return False, f"No se encontro ningun repuesto con el codigo '{codigo}'."

    return True, inventario[codigo]


# READ — busqueda por filtros (categoria, marca_moto, nombre parcial)
def filter_records(
    categoria: str = "",
    marca_moto: str = "",
    nombre: str = "",
    ordenar_por: str = "codigo",
) -> list[dict]:
    inventario = load_data()
    campos_validos = {"codigo", "nombre", "categoria", "marca_moto", "precio", "stock"}

    resultados = [
        r for r in inventario.values()
        if (not categoria or r["categoria"] == categoria.strip().lower())
        and (not marca_moto or r["marca_moto"] == marca_moto.strip().lower())
        and (not nombre or nombre.strip().lower() in r["nombre"].lower())
    ]

    if ordenar_por not in campos_validos:
        ordenar_por = "codigo"

    return sorted(resultados, key=lambda r: r[ordenar_por])


# UPDATE — solo actualiza los campos que se pasen
def update_record(codigo: str, cambios: dict) -> tuple[bool, str]:
    ok, mensaje = validar_codigo(codigo)
    if not ok:
        return False, f"Codigo invalido: {mensaje}"

    codigo = codigo.strip().upper()
    inventario = load_data()

    if codigo not in inventario:
        return False, f"No se encontro ningun repuesto con el codigo '{codigo}'."

    if not cambios:
        return False, "No se enviaron campos para actualizar."

    campos_editables = {"nombre", "categoria", "marca_moto", "precio", "stock", "descripcion"}
    campos_invalidos = [c for c in cambios if c not in campos_editables]
    if campos_invalidos:
        return False, f"Campos no permitidos: {', '.join(campos_invalidos)}."

    registro_actualizado = {**inventario[codigo], **cambios}

    ok, errores = validar_repuesto(registro_actualizado)
    if not ok:
        return False, "\n".join(errores)

    inventario[codigo] = _normalizar(registro_actualizado)

    if not save_data(inventario):
        return False, "Los cambios se procesaron pero no se pudieron guardar en disco."

    return True, f"Repuesto '{codigo}' actualizado correctamente."


# DELETE
def delete_record(codigo: str) -> tuple[bool, str]:
    ok, mensaje = validar_codigo(codigo)
    if not ok:
        return False, f"Codigo invalido: {mensaje}"

    codigo = codigo.strip().upper()
    inventario = load_data()

    if codigo not in inventario:
        return False, f"No se encontro ningun repuesto con el codigo '{codigo}'."

    del inventario[codigo]

    if not save_data(inventario):
        return False, f"El repuesto '{codigo}' se elimino en memoria pero no se pudo guardar en disco."

    return True, f"Repuesto '{codigo}' eliminado correctamente."
